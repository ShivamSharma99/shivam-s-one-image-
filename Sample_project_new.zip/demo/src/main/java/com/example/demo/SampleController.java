package com.example.demo;

import java.io.IOException;

import javax.servlet.http.HttpServletResponse;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class SampleController {

	@RequestMapping("/g")
	  void handleRequest(HttpServletResponse response) throws IOException {
	    response.sendRedirect("https://google.com");
	  }
}
